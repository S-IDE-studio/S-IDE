/**
 * Context Manager Types
 *
 * Type definitions for the Context Manager integration
 */
export {};
