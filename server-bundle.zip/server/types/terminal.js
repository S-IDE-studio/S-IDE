/**
 * Terminal Types
 *
 * Type definitions for terminal spawn options
 */
export {};
