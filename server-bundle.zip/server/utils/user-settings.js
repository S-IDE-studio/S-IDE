/**
 * User Settings Management
 *
 * Handles user-specific settings stored in ~/.side-ide/config.json
 */
import { existsSync } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";
const USER_CONFIG_DIR = join(homedir(), ".side-ide");
const USER_CONFIG_FILE = join(USER_CONFIG_DIR, "config.json");
// In-memory cache for settings
let settingsCache = null;
/**
 * Ensure config directory exists
 */
async function ensureConfigDir() {
    if (!existsSync(USER_CONFIG_DIR)) {
        await mkdir(USER_CONFIG_DIR, { recursive: true });
    }
}
/**
 * Load user settings from file
 */
export async function loadUserSettings() {
    if (settingsCache) {
        return settingsCache;
    }
    try {
        await ensureConfigDir();
        if (existsSync(USER_CONFIG_FILE)) {
            const data = await readFile(USER_CONFIG_FILE, "utf-8");
            settingsCache = JSON.parse(data);
            console.log("[USER_SETTINGS] Loaded user settings from", USER_CONFIG_FILE);
        }
        else {
            // Create default settings file
            settingsCache = {};
            await saveUserSettings(settingsCache);
            console.log("[USER_SETTINGS] Created new user settings file");
        }
    }
    catch (error) {
        console.error("[USER_SETTINGS] Failed to load settings:", error);
        settingsCache = {};
    }
    return settingsCache;
}
/**
 * Save user settings to file
 */
export async function saveUserSettings(settings) {
    try {
        await ensureConfigDir();
        const data = JSON.stringify(settings, null, 2);
        await writeFile(USER_CONFIG_FILE, data, "utf-8");
        settingsCache = settings;
        console.log("[USER_SETTINGS] Saved user settings to", USER_CONFIG_FILE);
    }
    catch (error) {
        console.error("[USER_SETTINGS] Failed to save settings:", error);
        throw error;
    }
}
/**
 * Get a specific setting value
 */
export async function getUserSetting(key) {
    const settings = await loadUserSettings();
    return settings[key];
}
/**
 * Set a specific setting value
 */
export async function setUserSetting(key, value) {
    const settings = await loadUserSettings();
    settings[key] = value;
    await saveUserSettings(settings);
}
/**
 * Clear settings cache (for testing)
 */
export function clearUserSettingsCache() {
    settingsCache = null;
}
/**
 * Get default shell ID from user settings
 */
export async function getDefaultShellId() {
    return getUserSetting("defaultShell");
}
/**
 * Set default shell ID in user settings
 */
export async function setDefaultShellId(shellId) {
    await setUserSetting("defaultShell", shellId);
}
