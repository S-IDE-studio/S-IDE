export function buildUnionTabs(presences) {
    const map = new Map();
    for (const p of presences) {
        for (const tab of p.tabs) {
            if (!tab?.syncKey)
                continue;
            if (!map.has(tab.syncKey)) {
                map.set(tab.syncKey, tab);
            }
        }
    }
    return [...map.values()];
}
export function pruneExpiredPresences(store, opts) {
    for (const [clientId, presence] of store.entries()) {
        if (opts.now - presence.updatedAt > opts.ttlMs) {
            store.delete(clientId);
        }
    }
}
