/**
 * Agent Interface
 *
 * Base interface that all agent adapters must implement.
 * Defines the contract for interacting with different AI CLI agents.
 */
export {};
