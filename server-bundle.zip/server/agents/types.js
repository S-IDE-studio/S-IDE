/**
 * Agent Type Definitions
 *
 * Shared types for agent system across S-IDE.
 */
export {};
