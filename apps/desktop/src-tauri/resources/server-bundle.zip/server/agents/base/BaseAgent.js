/**
 * Base Agent
 *
 * Abstract base class for agent adapters.
 * Provides common functionality that all agent adapters can use.
 */
import os from "node:os";
import path from "node:path";
/**
 * Abstract base class for agent adapters
 *
 * Implements common functionality and defines abstract methods
 * that specific agent adapters must implement.
 */
export class BaseAgent {
    id;
    name;
    icon;
    description;
    configPath;
    config = {};
    initialized = false;
    terminals = new Map();
    contexts = new Map();
    mcpServers = new Map();
    skills = new Map();
    constructor(id, name, icon, description) {
        this.id = id;
        this.name = name;
        this.icon = icon;
        this.description = description;
        // Set default config path - can be overridden by subclasses
        this.configPath = path.join(os.homedir(), `.${id}`);
    }
    // ==================== Lifecycle ====================
    async initialize() {
        if (this.initialized) {
            return;
        }
        await this.loadConfig();
        await this.loadMCPs();
        await this.loadSkills();
        this.initialized = true;
    }
    async isAvailable() {
        try {
            // Check if agent's config directory exists
            const fs = await import("node:fs/promises");
            await fs.access(this.configPath);
            return true;
        }
        catch {
            return false;
        }
    }
    async dispose() {
        this.terminals.clear();
        this.contexts.clear();
        this.mcpServers.clear();
        this.skills.clear();
        this.initialized = false;
    }
    async listTerminals() {
        return Array.from(this.terminals.values());
    }
    async getTerminal(terminalId) {
        return this.terminals.get(terminalId) || null;
    }
    // ==================== Context Management ====================
    async createContext(options) {
        const context = {
            id: this.generateId(),
            agentId: this.id,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            metadata: options.metadata || {},
            messageCount: 0,
        };
        this.contexts.set(context.id, context);
        return context;
    }
    async getContext(contextId) {
        return this.contexts.get(contextId) || null;
    }
    async updateContext(contextId, updates) {
        const context = this.contexts.get(contextId);
        if (!context) {
            throw new Error(`Context not found: ${contextId}`);
        }
        const updated = {
            ...context,
            ...updates,
            updatedAt: new Date().toISOString(),
        };
        this.contexts.set(contextId, updated);
    }
    async deleteContext(contextId) {
        this.contexts.delete(contextId);
    }
    async listContexts() {
        return Array.from(this.contexts.values());
    }
    async getConfig() {
        return { ...this.config };
    }
    async updateConfig(updates) {
        this.config = {
            ...this.config,
            ...updates,
        };
        await this.saveConfig();
    }
    async resetConfig() {
        this.config = {};
        await this.saveConfig();
    }
    // ==================== MCP/Skills Operations ====================
    /**
     * Load MCP servers from agent config
     * Default implementation - can be overridden
     */
    async loadMCPs() {
        // Default: load from config
        if (this.config.mcpServers) {
            for (const mcp of this.config.mcpServers) {
                this.mcpServers.set(mcp.id, {
                    ...mcp,
                    status: mcp.enabled !== false ? "active" : "inactive",
                });
            }
        }
    }
    /**
     * Save MCP servers to agent config
     * Default implementation - can be overridden
     */
    async saveMCPs() {
        // Save to config
        this.config.mcpServers = Array.from(this.mcpServers.values()).map((mcp) => ({
            id: mcp.id,
            name: mcp.name,
            command: mcp.command,
            args: mcp.args,
            env: mcp.env,
            enabled: mcp.status !== "inactive",
        }));
    }
    /**
     * Load Skills from agent config
     * Default implementation - can be overridden
     */
    async loadSkills() {
        // Default: load from config
        if (this.config.skills) {
            for (const skill of this.config.skills) {
                this.skills.set(skill.id, {
                    ...skill,
                    status: skill.enabled !== false ? "active" : "inactive",
                });
            }
        }
    }
    /**
     * Save Skills to agent config
     * Default implementation - can be overridden
     */
    async saveSkills() {
        // Save to config
        this.config.skills = Array.from(this.skills.values()).map((skill) => ({
            id: skill.id,
            name: skill.name,
            description: skill.description,
            enabled: skill.status !== "inactive",
            config: skill.config,
        }));
    }
    async listMCPs() {
        return Array.from(this.mcpServers.values());
    }
    async getMCP(mcpId) {
        return this.mcpServers.get(mcpId) || null;
    }
    async addMCP(mcp) {
        const mcpInfo = {
            ...mcp,
            status: "active",
        };
        this.mcpServers.set(mcp.id, mcpInfo);
        await this.saveMCPs();
    }
    async removeMCP(mcpId) {
        this.mcpServers.delete(mcpId);
        await this.saveMCPs();
    }
    async updateMCP(mcpId, updates) {
        const existing = this.mcpServers.get(mcpId);
        if (!existing) {
            throw new Error(`MCP not found: ${mcpId}`);
        }
        const updated = {
            ...existing,
            ...updates,
        };
        this.mcpServers.set(mcpId, updated);
        await this.saveMCPs();
    }
    async listSkills() {
        return Array.from(this.skills.values());
    }
    async getSkill(skillId) {
        return this.skills.get(skillId) || null;
    }
    async addSkill(skill) {
        const skillInfo = {
            ...skill,
            status: "active",
        };
        this.skills.set(skill.id, skillInfo);
        await this.saveSkills();
    }
    async removeSkill(skillId) {
        this.skills.delete(skillId);
        await this.saveSkills();
    }
    async updateSkill(skillId, updates) {
        const existing = this.skills.get(skillId);
        if (!existing) {
            throw new Error(`Skill not found: ${skillId}`);
        }
        const updated = {
            ...existing,
            ...updates,
        };
        this.skills.set(skillId, updated);
        await this.saveSkills();
    }
    async sendMessage(content) {
        const task = {
            id: this.generateId(),
            type: "prompt",
            content,
        };
        return this.executeTask(task);
    }
    // ==================== Utilities ====================
    generateId() {
        return `${this.id}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    }
    async ensureInitialized() {
        if (!this.initialized) {
            await this.initialize();
        }
    }
}
