/**
 * Response Utilities
 *
 * Standardized response formatting for API routes
 */
import { getErrorMessage } from "./error.js";
/**
 * Create a success response
 */
export function successResponse(c, data, status = 200) {
    return c.json({
        success: true,
        data,
        meta: {
            timestamp: new Date().toISOString(),
        },
    }, status);
}
/**
 * Create an error response
 */
export function errorResponse(c, message, status = 500, code) {
    return c.json({
        error: message,
        ...(code && { code }),
    }, status);
}
/**
 * Handle errors with standardized response
 */
export function handleResponseError(c, error, productionMode = false) {
    const status = error?.status ?? 500;
    const message = getErrorMessage(error) || "Unexpected error";
    if (productionMode && status === 500) {
        return errorResponse(c, "Internal server error", 500, "INTERNAL_ERROR");
    }
    return errorResponse(c, message, status);
}
/**
 * Create a validation error response
 */
export function validationError(c, field, message) {
    return errorResponse(c, `Validation failed for ${field}: ${message}`, 400, "VALIDATION_ERROR");
}
/**
 * Create a not found error response
 */
export function notFoundError(c, resource) {
    return errorResponse(c, `${resource} not found`, 404, "NOT_FOUND");
}
/**
 * Create a conflict error response
 */
export function conflictError(c, message) {
    return errorResponse(c, message, 409, "CONFLICT");
}
/**
 * Create an unauthorized error response
 */
export function unauthorizedError(c, message = "Unauthorized") {
    return errorResponse(c, message, 401, "UNAUTHORIZED");
}
/**
 * Create a forbidden error response
 */
export function forbiddenError(c, message = "Forbidden") {
    return errorResponse(c, message, 403, "FORBIDDEN");
}
